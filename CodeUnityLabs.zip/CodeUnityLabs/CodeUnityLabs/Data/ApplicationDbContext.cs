﻿using CodeUnityLabs.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace CodeUnityLabs.Data
{
    public class ApplicationDbContext : IdentityDbContext<IdentityUser>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<User> Users { get; set; } = null!;
        public DbSet<Authorizations> Authorizations { get; set; } = null!;
        public DbSet<WaitingList> WaitingList { get; set; } = null!;
        public DbSet<Rezervation> Reservations { get; set; } = null!;
        public DbSet<Resource> Resources { get; set; } = null!;
        public DbSet<UserType> UserTypes { get; set; } = null!;

        public DbSet<EquipmentType> EquipmentTypes { get; set; } = null!;
        public DbSet<Equipment> Equipments { get; set; } = null!;
        public DbSet<Classroom> Classrooms { get; set; } = null!;

        // ✅ UsageLog
        public DbSet<UsageLog> UsageLogs { get; set; } = null!;

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder); // MUST call this for Identity

            modelBuilder.Entity<UserType>().HasData(
                new UserType { User_Type_Id = 1, Type_Name = "Admin" },
                new UserType { User_Type_Id = 2, Type_Name = "Staff" },
                new UserType { User_Type_Id = 3, Type_Name = "Student" }
            );

            modelBuilder.Entity<User>()
                .HasIndex(u => u.Email)
                .IsUnique();

            modelBuilder.Entity<User>()
                .HasOne(u => u.UserType)
                .WithMany(ut => ut.Users)
                .HasForeignKey(u => u.User_Type_Id)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Authorizations>()
                .HasOne(a => a.User)
                .WithMany(u => u.Authorizations)
                .HasForeignKey(a => a.User_Id)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<Rezervation>()
                .HasOne(r => r.User)
                .WithMany(u => u.Rezervations)
                .HasForeignKey(r => r.User_Id)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<WaitingList>()
                .HasOne(w => w.User)
                .WithMany(u => u.WaitingLists)
                .HasForeignKey(w => w.User_Id)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<Equipment>()
                .HasOne(e => e.EquipmentType)
                .WithMany(t => t.Equipments)
                .HasForeignKey(e => e.Type_Id)
                .OnDelete(DeleteBehavior.Restrict);

            // ✅ UsageLog -> User
            modelBuilder.Entity<UsageLog>()
                .HasOne(ul => ul.User)
                .WithMany()
                .HasForeignKey(ul => ul.User_Id)
                .OnDelete(DeleteBehavior.Restrict);

            // ✅ UsageLog -> Resource
            modelBuilder.Entity<UsageLog>()
                .HasOne(ul => ul.Resource)
                .WithMany()
                .HasForeignKey(ul => ul.Resource_Id)
                .OnDelete(DeleteBehavior.Restrict);
        }
    }
}