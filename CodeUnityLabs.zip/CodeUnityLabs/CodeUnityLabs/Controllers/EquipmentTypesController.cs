﻿using CodeUnityLabs.Data;
using CodeUnityLabs.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CodeUnityLabs.Controllers
{
    public class EquipmentTypesController : Controller
    {
        private readonly ApplicationDbContext _context;

        public EquipmentTypesController(ApplicationDbContext context) => _context = context;

        public async Task<IActionResult> Index()
            => View(await _context.EquipmentTypes.AsNoTracking().ToListAsync());

        public async Task<IActionResult> Details(int? id)
        {
            if (id == null) return NotFound();

            var type = await _context.EquipmentTypes.AsNoTracking()
                .FirstOrDefaultAsync(x => x.Type_Id == id);

            return type == null ? NotFound() : View(type);
        }

        public IActionResult Create() => View();

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(EquipmentType equipmentType)
        {
            if (!ModelState.IsValid) return View(equipmentType);

            _context.Add(equipmentType);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null) return NotFound();

            var type = await _context.EquipmentTypes.FindAsync(id);
            return type == null ? NotFound() : View(type);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, EquipmentType equipmentType)
        {
            if (id != equipmentType.Type_Id) return NotFound();
            if (!ModelState.IsValid) return View(equipmentType);

            _context.Update(equipmentType);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null) return NotFound();

            var type = await _context.EquipmentTypes.AsNoTracking()
                .FirstOrDefaultAsync(x => x.Type_Id == id);

            return type == null ? NotFound() : View(type);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var type = await _context.EquipmentTypes.FindAsync(id);
            if (type != null)
            {
                _context.EquipmentTypes.Remove(type);
                await _context.SaveChangesAsync();
            }
            return RedirectToAction(nameof(Index));
        }
    }
}