﻿using CodeUnityLabs.Data;
using CodeUnityLabs.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace CodeUnityLabs.Controllers
{
    public class EquipmentsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public EquipmentsController(ApplicationDbContext context) => _context = context;

        public async Task<IActionResult> Index()
        {
            var list = await _context.Equipments
                .Include(e => e.EquipmentType)
                .AsNoTracking()
                .ToListAsync();

            return View(list);
        }

        public async Task<IActionResult> Details(int? id)
        {
            if (id == null) return NotFound();

            var equipment = await _context.Equipments
                .Include(e => e.EquipmentType)
                .AsNoTracking()
                .FirstOrDefaultAsync(e => e.Equipment_Id == id);

            return equipment == null ? NotFound() : View(equipment);
        }

        public IActionResult Create()
        {
            PopulateTypes();
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Equipment equipment)
        {
            if (!ModelState.IsValid)
            {
                PopulateTypes(equipment.Type_Id);
                return View(equipment);
            }

            _context.Add(equipment);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null) return NotFound();

            var equipment = await _context.Equipments.FindAsync(id);
            if (equipment == null) return NotFound();

            PopulateTypes(equipment.Type_Id);
            return View(equipment);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, Equipment equipment)
        {
            if (id != equipment.Equipment_Id) return NotFound();

            if (!ModelState.IsValid)
            {
                PopulateTypes(equipment.Type_Id);
                return View(equipment);
            }

            _context.Update(equipment);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null) return NotFound();

            var equipment = await _context.Equipments
                .Include(e => e.EquipmentType)
                .AsNoTracking()
                .FirstOrDefaultAsync(e => e.Equipment_Id == id);

            return equipment == null ? NotFound() : View(equipment);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var equipment = await _context.Equipments.FindAsync(id);
            if (equipment != null)
            {
                _context.Equipments.Remove(equipment);
                await _context.SaveChangesAsync();
            }
            return RedirectToAction(nameof(Index));
        }

        private void PopulateTypes(int? selectedTypeId = null)
        {
            ViewData["Type_Id"] = new SelectList(
                _context.EquipmentTypes.OrderBy(t => t.Type_Name),
                "Type_Id",
                "Type_Name",
                selectedTypeId
            );
        }
    }
}