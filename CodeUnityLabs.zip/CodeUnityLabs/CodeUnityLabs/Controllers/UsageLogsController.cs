﻿using CodeUnityLabs.Data;
using CodeUnityLabs.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace CodeUnityLabs.Controllers
{
    public class UsageLogsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public UsageLogsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // ✅ Para teste (liberado)
        private bool IsAdmin() => HttpContext.Session.GetInt32("UserTypeId") == 1;
        private bool IsStaff() => HttpContext.Session.GetInt32("UserTypeId") == 2;
        private bool IsUser() => HttpContext.Session.GetInt32("UserTypeId") == 3;

        // GET: UsageLogs
        public async Task<IActionResult> Index()
        {
            var list = await _context.UsageLogs
                .Include(x => x.User)
                .Include(x => x.Resource)
                .AsNoTracking()
                .ToListAsync();

            return View(list);
        }

        // GET: UsageLogs/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null) return NotFound();

            var item = await _context.UsageLogs
                .Include(x => x.User)
                .Include(x => x.Resource)
                .AsNoTracking()
                .FirstOrDefaultAsync(x => x.Usage_Id == id);

            return item == null ? NotFound() : View(item);
        }

        // GET: UsageLogs/Create
        public IActionResult Create()
        {
            PopulateDropdowns();
            return View();
        }

        // POST: UsageLogs/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(UsageLog usageLog)
        {
            // ✅ Para teste: permite todos (se quiser restringir depois, eu ajusto)
            // if (!IsAdmin() && !IsStaff()) return Forbid();

            if (!ModelState.IsValid)
            {
                PopulateDropdowns(usageLog.User_Id, usageLog.Resource_Id);
                return View(usageLog);
            }

            _context.Add(usageLog);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        // GET: UsageLogs/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            // ✅ Para teste: permite todos
            // if (!IsAdmin() && !IsStaff()) return Forbid();

            if (id == null) return NotFound();

            var item = await _context.UsageLogs.FindAsync(id);
            if (item == null) return NotFound();

            PopulateDropdowns(item.User_Id, item.Resource_Id);
            return View(item);
        }

        // POST: UsageLogs/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, UsageLog usageLog)
        {
            // ✅ Para teste: permite todos
            // if (!IsAdmin() && !IsStaff()) return Forbid();

            if (id != usageLog.Usage_Id) return NotFound();

            if (!ModelState.IsValid)
            {
                PopulateDropdowns(usageLog.User_Id, usageLog.Resource_Id);
                return View(usageLog);
            }

            _context.Update(usageLog);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        // GET: UsageLogs/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            // ✅ Para teste: permite todos
            // if (!IsAdmin() && !IsStaff()) return Forbid();

            if (id == null) return NotFound();

            var item = await _context.UsageLogs
                .Include(x => x.User)
                .Include(x => x.Resource)
                .AsNoTracking()
                .FirstOrDefaultAsync(x => x.Usage_Id == id);

            return item == null ? NotFound() : View(item);
        }

        // POST: UsageLogs/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            // ✅ Para teste: permite todos
            // if (!IsAdmin() && !IsStaff()) return Forbid();

            var item = await _context.UsageLogs.FindAsync(id);
            if (item != null)
            {
                _context.UsageLogs.Remove(item);
                await _context.SaveChangesAsync();
            }
            return RedirectToAction(nameof(Index));
        }

        private void PopulateDropdowns(int? userId = null, int? resourceId = null)
        {
            ViewData["User_Id"] = new SelectList(
                _context.Users.OrderBy(u => u.Name),
                "User_Id",
                "Name",
                userId
            );

            ViewData["Resource_Id"] = new SelectList(
                _context.Resources.OrderBy(r => r.Resource_Name),
                "Resource_Id",
                "Resource_Name",
                resourceId
            );
        }
    }
}