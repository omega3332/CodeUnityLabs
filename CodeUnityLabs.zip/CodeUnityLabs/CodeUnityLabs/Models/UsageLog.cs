﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CodeUnityLabs.Models
{
    [Table("UsageLog")]
    public class UsageLog
    {
        [Key]
        [Column("Usage_Id")]
        public int Usage_Id { get; set; }

        [Column("User_Id")]
        public int User_Id { get; set; }

        [Column("Resource_Id")]
        public int Resource_Id { get; set; }

        [Column("Start_Time")]
        public DateTime Start_Time { get; set; }

        [Column("End_Time")]
        public DateTime End_Time { get; set; }

        [Column("Total_Cost")]
        public decimal? Total_Cost { get; set; }

        [ForeignKey(nameof(User_Id))]
        public User? User { get; set; }

        [ForeignKey(nameof(Resource_Id))]
        public Resource? Resource { get; set; }
    }
}