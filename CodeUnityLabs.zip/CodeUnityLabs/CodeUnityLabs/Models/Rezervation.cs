﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CodeUnityLabs.Models
{
    [Table("Reservations")]
    public class Rezervation
    {
        [Key]
        [Column("Reservation_Id")]
        public int Reservation_Id { get; set; }

        [Column("User_Id")]
        public int User_Id { get; set; }

        [Column("Resource_Id")]
        public int? Resource_Id { get; set; }

        [Column("Room_Id")]
        public int? Room_Id { get; set; }

        [Column("Start_Time")]
        public DateTime Start_Time { get; set; }

        [Column("End_Time")]
        public DateTime End_Time { get; set; }

        [Column("Status")]
        public string? Status { get; set; }  // nvarchar na BD

        [Column("Priority")]
        public int? Priority { get; set; }

        [Column("ClassName")]
        public string? ClassName { get; set; }

        [ForeignKey(nameof(User_Id))]
        public User? User { get; set; }

        [ForeignKey(nameof(Resource_Id))]
        public Resource? Resource { get; set; }

        // ✅ NÃO EXISTE NA BD, então deixa comentado
        // public int? Equipment_Id { get; set; }
        // public Equipment? Equipment { get; set; }
    }
}