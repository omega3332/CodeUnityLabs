﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CodeUnityLabs.Models
{
    [Table("Classrooms")]
    public class Classroom
    {
        [Key]
        [Column("Room_Id")]
        public int Room_Id { get; set; }

        [Column("Room_Name")]
        public string? Room_Name { get; set; }

        [Column("Capacity")]
        public int Capacity { get; set; }

        [Column("status")]
        public string? Status { get; set; } // nvarchar

        [Column("priority")]
        public bool Priority { get; set; }  // ✅ bit
    }
}