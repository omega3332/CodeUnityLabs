﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CodeUnityLabs.Models
{
    [Table("EquipmentTypes")]
    public class EquipmentType
    {
        [Key]
        [Column("type_id")]
        public int Type_Id { get; set; }

        [Column("type_name")]
        public string? Type_Name { get; set; }

        public ICollection<Equipment> Equipments { get; set; } = new List<Equipment>();
    }
}