﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CodeUnityLabs.Models
{
    [Table("Equipments")]
    public class Equipment
    {
        [Key]
        [Column("equipment_id")]
        public int Equipment_Id { get; set; }

        [Column("name")]
        public string? Name { get; set; }

        [Column("type_id")]
        public int Type_Id { get; set; }

        // status na tua BD parece ser texto
        [Column("status")]
        public string? Status { get; set; }

        [ForeignKey(nameof(Type_Id))]
        public EquipmentType? EquipmentType { get; set; }
    }
}