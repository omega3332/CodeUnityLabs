﻿namespace CodeUnityLabs.Models
{
    public enum ReservationStatus
    {
        Pending,
        Approved,
        Waiting,
        Rejected
    }
}
